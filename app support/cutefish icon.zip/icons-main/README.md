# Icons

System default icon theme, based on [vinceliuice](https://github.com/vinceliuice)'s whitesur.

## Build and Install

```bash
mkdir build
cd build
cmake ..
make
sudo make install
```

## License

This project has been licensed by GPLv3.
